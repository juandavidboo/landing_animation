document.getElementById('banner').addEventListener('click', toClickTag1, false);
document.getElementById('prescribing').addEventListener('click', toClickTag2, false);
document.getElementById('prescribing_isi').addEventListener('click', toClickTag2, false);
document.getElementById('medication').addEventListener('click', toClickTag3, false);
document.getElementById('medication_isi').addEventListener('click', toClickTag3, false);
document.getElementById('medwatch_isi').addEventListener('click', toClickTag4, false);
document.getElementById('helps_isi').addEventListener('click', toClickTag5, false);
document.getElementById('logo_pfizer').addEventListener('click', toClickTag6, false);

function toClickTag1(e) { Enabler.exit('ClickTag1') }
function toClickTag2(e) { Enabler.exit('ClickTag2') }
function toClickTag3(e) { Enabler.exit('ClickTag3') }
function toClickTag4(e) { Enabler.exit('ClickTag4') }
function toClickTag5(e) { Enabler.exit('ClickTag5') }
function toClickTag6(e) { Enabler.exit('ClickTag6') }