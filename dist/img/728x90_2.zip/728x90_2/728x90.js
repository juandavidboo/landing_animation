/*var TL = new TimelineMax();
TL.add( TweenMax.to('#wrapper', 0, {opacity: 1}))
TL.add([
  TweenMax.set(['#step1', '#step2', '#step3', '#step4', '#isi'], {
      rotationZ: 0.01, force3D:true, transformStyle: "preserve-3d"
    }),
]);
TL.add([
    TweenMax.to('#bg01', 0.5, {opacity: 1, ease:Power1.easeInOut,}),
    TweenMax.to('#textLeft01', 1, {left: 60, opacity: 1, ease:Power1.easeInOut}),
    TweenMax.to('#textRight01', 1, {left: 165, opacity: 1, ease:Power1.easeInOut}),
    TweenMax.to('#textTop', 0.9, {left: 268, opacity: 1, ease:Power1.easeInOut}),
    TweenMax.to('#textLeft01, #textRight01', 1, {opacity: 0, ease:Power1.easeInOut, delay: 2}),
]);
TL.add([
    TweenMax.to('#bg01', 2, {left: 248, ease:Power1.easeInOut,}),
    TweenMax.to('#textLeft02', 2, {opacity: 1, ease:Power1.easeInOut, delay: 0.6}),
    TweenMax.to('#textRight02', 2, {opacity: 1, ease:Power1.easeInOut, delay: 0.7}),
    TweenMax.to('#textRightSec01', 2, {opacity: 1, ease:Power1.easeInOut, delay: 0.8}),
], "-=0.4");
TL.add([
    TweenMax.to('#bg01', 1, {scaleY:(0.5), ease:Power1.easeInOut, delay: 1}),
    TweenMax.to('#textLeft02, #textRightSec01', 1, {opacity: 0, ease:Power1.easeInOut}),
    TweenMax.to('#textTop02', 0.9, {opacity: 1, ease:Power1.easeInOut, delay: 1.2}),
    TweenMax.to('#textLeft03', 1, {opacity: 1, ease:Power1.easeInOut, delay: 1.3}),
    TweenMax.to('#textRightSec02, #textRightThird', 1, {opacity: 1, ease:Power1.easeInOut, delay: 1.4}),
], "-=0.4");

TL.add([
    TweenMax.to('#textLeft03, #textRight02, #textRightSec01, #textRightSec02, #textRightThird', 1, {opacity: 0, ease:Power1.easeInOut, delay: 3.1}),
    TweenMax.to('#bg01', 1, {opacity: 0, ease:Power1.easeInOut, delay: 3}),
    TweenMax.to('#textLeft04', 1, {opacity: 1, ease:Power1.easeInOut, delay: 3.1}),
    TweenMax.to('#textRight04', 1, {opacity: 1, ease:Power1.easeInOut, delay: 3.2}),
], "-=0.4");

TL.add([
    TweenMax.to('#textLeft04, #textRight04, #textTop02', 1, {opacity: 0, ease:Power1.easeInOut, delay: 3}),
    TweenMax.to('#logo_xeljanz, #textLeft05', 1, {opacity: 1, ease:Power1.easeInOut, delay: 3.1}),
    TweenMax.to('#isi, #txt_top_isi, #txt_bottom_isi', 1, { y:-100, autoAlpha:1, ease:Power4.easeOut, delay: 3.2}),
    TweenMax.to('#banner', 1, { width:438, height:75, ease:Power4.easeOut, delay: 0.2 }),
], "-=0.4");
var currentDuration = TL.duration().toFixed(2); console.log("Current Duration = " + currentDuration + " seg");
if (Enabler.isPageLoaded()) {
    pageLoadedHandler();
}
else {
    Enabler.addEventListener(studio.events.StudioEvent.PAGE_LOADED, pageLoadedHandler);
}
function pageLoadedHandler() {
    $('#wrapper').css("background-image","none");
}*/
var tl = new TimelineLite();
tl.defaultEase = Power1.easeInOut;
tl.set(['#step1', '#step2', '#step3', '#step4', '#isi'], {rotationZ: 0.01, force3D:true, transformStyle: "preserve-3d"})
// Step1
.to('#bg01', 0.5, {opacity: 1}, "step1")
.to('#textLeft01', 1, {left: 60, opacity: 1}, "step1")
.to('#textRight01', 1, {left: 165, opacity: 1}, "step1")
.to('#textTop', 0.9, {left: 268, opacity: 1}, "step1")
.to('#textLeft01, #textRight01', 1, {opacity: 0}, "step1+=2")
// Step2
.to('#bg01', 2, {left: 248}, "step2")
.to('#textLeft02', 2, {opacity: 1}, "step2+=0.6")
.to('#textRight02', 2, {opacity: 1}, "step2+=0.7")
.to('#textRightSec01', 2, {opacity: 1}, "step2+=0.8")
//step3
.to('#textLeft02, #textRightSec01', 1, {opacity: 0, ease:Power1.easeInOut}, "step3")
.to('#bg01', 1, {scaleY:(0.5)}, "step3+=1")
.to('#textTop02', 0.9, {opacity: 1}, "step3+=1.2")
.to('#textLeft03', 1, {opacity: 1}, "step3+=1.3")
.to('#textRightSec02, #textRightThird', 1, {opacity: 1}, "step3+=1.4")
//step4
.to('#textLeft03, #textRight02, #textRightSec01, #textRightSec02, #textRightThird', 1, {opacity: 0}, "step4+=0.1")
.to('#bg01', 1, {opacity: 0}, "step4")
.to('#textLeft04', 1, {opacity: 1}, "step4+=0.1")
.to('#textRight04', 1, {opacity: 1}, "step4+=0.2")
//step5
.to('#textLeft04, #textRight04, #textTop02', 1, {opacity: 0}, "step5")
.to('#logo_xeljanz, #textLeft05', 1, {opacity: 1}, "step5+=0.1")
.to('#isi, #txt_top_isi, #txt_bottom_isi', 1, { y:-100, autoAlpha:1, ease:Power4.easeOut}, "step5+=0.2")
.to('#banner', 1, { width:438, height:75, ease:Power4.easeOut,}, "step5+=0.2")
var currentDuration = tl.duration().toFixed(2); console.log("Current Duration = " + currentDuration + " seg");
if (Enabler.isPageLoaded()) {
    pageLoadedHandler();
}
else {
    Enabler.addEventListener(studio.events.StudioEvent.PAGE_LOADED, pageLoadedHandler);
}
function pageLoadedHandler() {
    $('#wrapper').css("background-image","none");
}